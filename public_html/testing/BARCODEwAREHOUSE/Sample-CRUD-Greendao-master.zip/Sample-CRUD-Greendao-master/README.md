## Sample CRUD Greendao - Aplikasi Catat Pengeluaran

Greendao Documentation : https://github.com/greenrobot/greenDAO

#### Screenshot :
<img src="https://raw.githubusercontent.com/farizdotid/Sample-CRUD-Greendao/master/screenshot/Screenshot_20190215-150539.png" width="300" height="600" />
<img src="https://raw.githubusercontent.com/farizdotid/Sample-CRUD-Greendao/master/screenshot/Screenshot_20190215-150608.png" width="300" height="600" />
<img src="https://raw.githubusercontent.com/farizdotid/Sample-CRUD-Greendao/master/screenshot/Screenshot_20190215-150616.png" width="300" height="600" />
<img src="https://raw.githubusercontent.com/farizdotid/Sample-CRUD-Greendao/master/screenshot/Screenshot_20190215-150626.png" width="300" height="600" />
<img src="https://raw.githubusercontent.com/farizdotid/Sample-CRUD-Greendao/master/screenshot/Screenshot_20190215-150638.png" width="300" height="600" />
<img src="https://raw.githubusercontent.com/farizdotid/Sample-CRUD-Greendao/master/screenshot/Screenshot_20190215-150648.png" width="300" height="600" />